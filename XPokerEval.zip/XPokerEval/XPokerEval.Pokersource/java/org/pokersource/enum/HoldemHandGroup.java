// $Id: HoldemHandGroup.java,v 1.3 2002/06/13 03:04:56 mjmaurer Exp $

package org.pokersource.enum;

/**
   @author Michael Maurer <mjmaurer@yahoo.com>
*/

public class HoldemHandGroup extends HandGroup {
  // constructor of form: <init>(String groupSpec);

}
