/* $Id: jniutil.h,v 1.1 2002/05/01 02:45:17 mjmaurer Exp $ */

extern void jniThrow(JNIEnv *env, jclass class, char *msg);
