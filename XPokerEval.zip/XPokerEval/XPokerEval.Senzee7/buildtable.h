

short int* create_table(const char* saveAs);
void destroy_table(short int*);
