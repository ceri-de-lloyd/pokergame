package PSim;

public class SimResults
{
    public float win;
    public float tie;
    public float lose;

    public float winSd;
    public float tieSd;
    public float loseSd;

    public float dNow;
    public float d94;
    public float d90;
    public long evaluations;
}